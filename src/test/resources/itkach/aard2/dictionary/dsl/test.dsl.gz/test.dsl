#NAME "Test DSL"
#INDEX_LANGUAGE "English"
#CONTENTS_LANGUAGE "French"

{{a comment
spanning lines}}
Africa
Afrique
	[m1]Africa[/m]
	[m1]Afrique[/m]

{to }have
	[m1][b]1)[/b] [trn]avoir[/trn] [p]v.[/p][/m]
	[m2][ex]I ~ a cat[/ex][/m]
	[m1]see <<possess>>, [ref]own[/ref][/m]
	@ ~ fun
	s'amuser
	@
	[s]have.wav[/s] [s]cat.png[/s]

(re)turn(s)
	[m1]{{inline comment}}tourner [c red]rouge[/c] [url]https://example.org[/url][/m]

Straße \[escaped\]
	[m1]rue & <b>[/m]
